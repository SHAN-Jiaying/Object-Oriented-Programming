package question5;

import java.util.Scanner;

public class CLI {
	private static Scanner input = new Scanner(System.in);

	private static String readLine(String message) {
		System.out.print(message);//print the message
		return input.nextLine();
	}

	private static int readPosInt(String message) {
        while (true) {
            System.out.print(message);//print the message
            try {
                int num = input.nextInt();//read the next line from user
                input.nextLine();
                if (num >= 0) {
                    return num;
                } 
                
                else {//num<0
                    System.out.println("Positive integers only!");
                }
                
            } catch (java.util.InputMismatchException e) {//not a integer
                System.out.println("You must type an integer!");
                input.nextLine();
            }
        }
    }

	public static void main(String[] args) {
		String str1 = readLine("Type some text: ");
		System.out.println("Text read is: " + str1);
		int i = readPosInt("Type an integer: ");
		System.out.println("Integer read is: " + i);
		String str2 = readLine("Type some text again: ");
		System.out.println("Text read is: " + str2);
	}

}