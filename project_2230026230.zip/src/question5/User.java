package question5;

public abstract class User implements IUser {
	
	private String name;
	private int book;

	public User(String name, int book) {
		this.name = name;
		this.book = book;
	}

	public String getName() {
		return name;
	}

	public int getBook() {//show the amount of user borrow
		return book;
	}

	protected void setBook(int book) {//changes the number of books borrowed by the user
		this.book = book;
	}

	public abstract void moreBook(int number)  throws NotALenderException;//to increase the number of books borrowed or lent by the user

	public static void testUser() {
		
	}
}
