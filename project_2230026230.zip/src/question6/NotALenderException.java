package question6;

public class NotALenderException extends Exception{
	public NotALenderException(String msg) {
		super(msg);
	}
}

