package question6;

public class Borrower extends User {
    public Borrower(String name, int book) throws NotALenderException {
        super(name, book);
        if (book < 0) {//If the number of books given as argument is strictly less than zero
            throw new NotALenderException("A new borrower cannot lend books.");
        }
    }

    @Override
    public void moreBook(int number) throws NotALenderException {
        int newBook = getBook() + number;
        if (newBook < 0) {//a borrower cannot lend books
            throw new NotALenderException("A borrower cannot lend " + -(getBook() + number) + " book(s).");
        }
        setBook(newBook);
    }

    public static void testBorrower() {
        try {
            Borrower borrower = new Borrower("Bob", -1);
        } catch (NotALenderException e) {
            System.out.println(e.getMessage().equals("A new borrower cannot lend books."));
        }
        try {
            Borrower borrower = new Borrower("Bob", 10);
            System.out.println(borrower.getName().equals("Bob"));
            System.out.println(borrower.getBook() == 10);
            borrower.setBook(5);
            System.out.println(borrower.getBook() == 5);
            borrower.moreBook(2);
            System.out.println(borrower.getBook() == 7);
            borrower.moreBook(-2);
            System.out.println(borrower.getBook() == 5);
            borrower.moreBook(-5);
            System.out.println(borrower.getBook() == 0);
            borrower.moreBook(-1);
        } catch (NotALenderException e) {
            System.out.println(e.getMessage().equals("A borrower cannot lend 1 book(s)."));
        }
    }

}