package question6;

import java.util.*;

public class Library {
	private String name;
	private ArrayList<IUser> users = new ArrayList<IUser>();

	public Library(String name) {
		this.name = name;
	}

	public void addUser(IUser user) {
		users.add(user);
	}

	public int totalBorrowedBooks() {// the total number of books borrowed by all users
		int total = 0;
		for (IUser user : users) {
			total += user.getBook();
		}
		return total;
	}

	public int getBook(String name) throws UnknownUserException {//whether the user name is in library
		for (IUser user : users) {
			if (user.getName().equals(name)) {// to find the consumer that you want
				return user.getBook();
			}
		}//the library does not have a user with the given name
		throw new UnknownUserException("User " + name + " unknown.");
	}

	public void moreBook(String name, int number) throws UnknownUserException, NotALenderException {
		for (IUser user : users) {
			if (user.getName().equals(name)) {// to find the consumer that you want
				user.moreBook(number);
				return;
			}
		}//the library does not have a user with the given name
		throw new UnknownUserException("User " + name + " unknown.");
	}

	public static void testLibrary() {
		Library li = new Library("UIC Library");
		System.out.println(li.totalBorrowedBooks() == 0);
		li.addUser(new Lender("L1", 10));
		try {
			System.out.println(li.getBook("L1") == -10);
			System.out.println(li.totalBorrowedBooks() == -10);
			li.addUser(new Borrower("B1", 20));
			System.out.println(li.getBook("L1") == -10);
			System.out.println(li.getBook("B1") == 20);
			System.out.println(li.totalBorrowedBooks() == 10);
			li.getBook("B2");
		} catch(UnknownUserException ex) {
			System.out.println(ex.getMessage().equals("User B2 unknown."));
		} catch(NotALenderException ex) {
			// This should never happen!
			System.out.println(false);
		}
		//* More test cases are needed…
		//* Test NotALenderException
		try{
			li.addUser(new Lender("L2",10));
 			li.addUser(new Borrower("B3", -10));
		} catch (NotALenderException e) {
			System.out.println(e.getMessage().equals("A new borrower cannot lend books."));
 		}
		//*  Test moreBook()
		try{
			li.addUser(new Borrower("B4", 10));
			li.moreBook("B4", -11);
		} catch(NotALenderException e){
			System.out.println(e.getMessage().equals("A borrower cannot lend 1 book(s)."));
		} catch (UnknownUserException e) {
			// This should never happen!
			System.out.println(false);
		}
		//test addUser to add lender and borrower
		try {
			li.addUser(new Lender("L3", -10));
			li.moreBook("L3", 15);
			li.addUser(new Borrower("B3", 10));
			li.moreBook("B3", 8);
			System.out.println(li.getBook("B3") == 18);
			System.out.println(li.getBook("L3") == -5);
			li.moreBook("L4", 0);
		}catch(UnknownUserException ex) {
			System.out.println(ex.getMessage().equals("User L4 unknown."));
		}catch(NotALenderException ex) {
			System.out.println(ex.getMessage());
		}
    }
}
