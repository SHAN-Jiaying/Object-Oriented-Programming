package question7;

import java.awt.*;
import javax.swing.*;

public class ViewSimple extends JFrame implements ModelListener {
	
	private Library model;
	private ControllerSimple controller;
	private JLabel label;

	public ViewSimple(Library model, ControllerSimple controller) {
		this.model = model;
		this.controller = controller;
		this.setTitle("View");
		this.setSize(400, 300);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		label = new JLabel("total number of borrowed books: " + model.totalBorrowedBooks());
		update();
		this.add(label);
		this.setVisible(true);
	}

	public void update() {
		label.setText("total number of borrowed books: " + model.totalBorrowedBooks());//print out 
	}
}
