package question7;

public class ControllerSimple {
	
	private Library m;
	
	public ControllerSimple(Library m) {
		this.m = m;
	}
}