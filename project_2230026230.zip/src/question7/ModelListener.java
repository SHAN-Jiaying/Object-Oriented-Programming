package question7;

public interface ModelListener {
	public void update();
}