package question10;

public class ControllerSimple extends Controller{
	
	private Library m;
	
	public ControllerSimple(Library m) {
		super(m);
	}
}