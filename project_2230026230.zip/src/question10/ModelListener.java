package question10;

public interface ModelListener {
	public void update();
}