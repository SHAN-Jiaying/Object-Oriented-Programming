package question10;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ViewMoreBook extends View<ControllerMoreBook> {
	private JTextField t1;
	private JTextField t2;
	
	public ViewMoreBook(Library m, ControllerMoreBook c) {
		super(m,c);
		this.setTitle("View MoreBook");
		this.setSize(400,300);
		this.setLayout(new GridLayout(3, 1));
		t1 = new JTextField("Type a user name here");
		t2 = new JTextField("Type a numebr of books here");
		this.add(t1);
		this.add(t2);
		JButton b1 = new JButton("More Book");
		this.add(b1);
		this.setLocation(0,400);
		b1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if(c.moreBook(t1.getText(), t2.getText()).equals("") == false){//judge moreBook return is different from ""
					String name = t1.getText();//obtain the t1's text
	        		String result = t2.getText();//obtain the t2's text
					JOptionPane.showMessageDialog(null, c.moreBook(name, result),"Message", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		this.setVisible(true);
	}
	
	public void update() {
		
	}
}
