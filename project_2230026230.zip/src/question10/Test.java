package question10;

public class Test {
	public static void main(String[] args) {
		User.testUser();
		Lender.testLender();
		Borrower.testBorrower();
		Library.testLibrary();
	}
}