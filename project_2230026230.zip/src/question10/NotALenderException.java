package question10;

public class NotALenderException extends Exception{
	public NotALenderException(String msg) {
		super(msg);
	}
}

