package question10;

public class Controller {
	
	protected Library m;
	
	public Controller(Library m) {
		this.m = m;
	}
	
}