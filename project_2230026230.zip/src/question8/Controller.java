package question8;

public class Controller {
	
	protected Library m;
	
	public Controller(Library m) {
		this.m = m;
	}
	
}