package question8;

import java.awt.*;
import javax.swing.*;

public class ViewSimple extends View<Controller> implements ModelListener {

	private JLabel label;

	public ViewSimple(Library m, ControllerSimple c) {
		super(m, c);
		this.setTitle("View");
		this.setSize(400, 300);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		label = new JLabel("total number of borrowed books: " + m.totalBorrowedBooks());
		update();
		this.add(label);
		this.setVisible(true);
	}

	public void update() {
		label.setText("total number of borrowed books: " + m.totalBorrowedBooks());//print out 
	}
}
