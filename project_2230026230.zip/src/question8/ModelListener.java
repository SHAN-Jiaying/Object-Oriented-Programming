package question8;

public interface ModelListener {
	public void update();
}