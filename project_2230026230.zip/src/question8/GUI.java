package question8;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class GUI {
    public static void main(String[] args) {
    	
        Runnable runnable = new Runnable() {
        	
            public void run() {
                Library library = new Library("UIC Library");
                
    			try {
					library.addUser(new Borrower("Bob", 10));
					library.addUser(new Lender("Linda", 5));
				} 
    			catch (NotALenderException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    			
                ControllerSimple controller = new ControllerSimple(library);
                ViewSimple view = new ViewSimple(library, controller);
            }
        };
        
        SwingUtilities.invokeLater(runnable);
    }
}