package question12;

public interface ModelListener {
	public void update();
}