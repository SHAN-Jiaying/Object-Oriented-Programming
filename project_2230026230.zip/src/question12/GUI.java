package question12;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class GUI {
    public static void main(String[] args) {
    	javax.swing.SwingUtilities.invokeLater(new Runnable() {
    		public void run() {
				Library lib = new Library("UIC Library");
				try {
					lib.addUser(new Lender("Linda", 0));
					lib.addUser(new Lender("Linda", 5));
					lib.addUser(new Borrower("Bob", 10));
				} catch (NotALenderException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				ControllerSimple cs = new ControllerSimple(lib);
				ViewSimple vs = new ViewSimple(lib, cs);
				
				ControllerGetBook cgb = new ControllerGetBook(lib);
				ViewGetBook vgb = new ViewGetBook(lib, cgb);
				
				ControllerMoreBook cmb = new ControllerMoreBook(lib);
				ViewMoreBook vmb = new ViewMoreBook(lib, cmb);
				
				ControllerCreate cc = new ControllerCreate(lib);
				ViewCreate vc = new ViewCreate(lib, cc);
				
				ControllerHistory ch = new ControllerHistory(lib);
				ViewHistory vh = new ViewHistory(lib, ch);
            }
        });
    }
}