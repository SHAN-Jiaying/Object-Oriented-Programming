package question12;

public class NotALenderException extends Exception{
	public NotALenderException(String msg) {
		super(msg);
	}
}

