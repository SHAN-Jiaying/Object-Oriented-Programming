package question12;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class ControllerHistory extends Controller{
	
	public ControllerHistory(Library m) {
		super(m);
	}
	
}
