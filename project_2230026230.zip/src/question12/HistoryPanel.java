package question12;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

public class HistoryPanel extends JPanel{
	private Library m;
	public HistoryPanel(Library m) {
		this.m = m;
	}
	
	private int historyMax(ArrayList<Integer> a) {//max
		int maxNum = 0;
		for(int i = 0;i < a.size(); i++) {//search maximum number
			if(a.get(i) > maxNum) {
				maxNum = a.get(i);
			}
		}
		return maxNum;
	}
	
	private int historyMin(ArrayList<Integer> a) {//min
		int minNum = 0;
		for(int i = 0;i < a.size();i++) {//search minimum number
			if(a.get(i) < minNum) {
				minNum = a.get(i);
			}
		}
		return minNum;
	}
	
	private int historyRange(ArrayList<Integer> a) {//return 10 if the difference between the man and min of the integers 
		if(historyMax(a) - historyMin(a) <= 10) {//in the arraylist is strictly less than 10
			return 10;
		}
		else {
			return historyMax(a) - historyMin(a); 
		}
	}
	
	protected void paintComponent(Graphics g) {
		int min = historyMin(m.getHistory());
		int range = historyRange(m.getHistory());
		int maxX = getWidth() - 1;
		int maxY = getHeight() - 1;
		int zero = maxY + min * maxY / range;
		g.setColor(Color.BLUE);
		g.drawLine(0, zero, maxX, zero);
		int x;
		int y;
		//before draw the line between (x,y) to get history (x,y)
		int historyx;
		int historyy;
		for(int i = 1; i < m.getHistory().size(); i++ ) {
			x = 10 * i;
			y = zero - m.getHistory().get(i) * maxY/range;
			historyx = 10*(i-1);
			historyy = zero - m.getHistory().get(i - 1) * maxY/range;
			g.setColor(Color.red);//set color red
			g.drawLine(historyx, historyy, x, y);//draw the history(x,y) between (x,y)
		}
	}
}
