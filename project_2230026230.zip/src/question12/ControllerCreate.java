package question12;

public class ControllerCreate extends Controller {
	public ControllerCreate(Library m) {
		super(m);
	}

	public String create(String name, String number, int type) {
		try {
			int a = Integer.parseInt(number);
			if(type == 0) {
				Lender lender = new Lender(name,a);//create a lender object
				m.addUser(lender);//add to library
				return "";
			}
			else if(type == 1) {
				Borrower borrower = new Borrower(name,a);//create a borrower object
				m.addUser(borrower);//add to library
				return "";
			}else {
				return "Unknown type!";
			}
		}catch(NotALenderException e) {
			return e.getMessage();//catch NotALenderException
		}catch(NumberFormatException e) {
			return e.getMessage();//catch NumberFormatException
		}
	}
}
