package question12;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class ViewHistory extends View<ControllerHistory>{
	public ViewHistory(Library m, ControllerHistory c) {
		super(m,c);
		this.setTitle("View History");
		this.setSize(400,300);
		this.setLocation(800,400);
		HistoryPanel historyPanel = new HistoryPanel(m);
		this.add(historyPanel);
		this.setVisible(true);
	}
	
	public void update() {
		repaint();
	}
}
