package question12;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class ViewGetBook extends View<ControllerGetBook>{
	private JTextField t;
	public ViewGetBook(Library m, ControllerGetBook c) {
		super(m,c);
		this.setTitle("View GeetBook");
		this.setSize(400,300);
		this.setLayout(new GridLayout(2,1));
        t = new JTextField("Type user name here");
        this.add(t);
        JButton button1 = new JButton("Tell me the book number");
        this.add(button1);
        button1.addActionListener(new ActionListener(){
        	public void actionPerformed(ActionEvent e) {
        		String name = t.getText();
        		String result = c.getBook(name);
        		JOptionPane.showMessageDialog(null, result);
        	}
        });
        this.setVisible(true);
	}
	
	public void update() {
		
	}
}
