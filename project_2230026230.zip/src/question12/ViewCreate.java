package question12;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class ViewCreate extends View<ControllerCreate> {
	private JTextField t1; 
	private JTextField t2;
	private JComboBox<String> cb;
	public ViewCreate(Library m, ControllerCreate c) {
		super(m,c);
		this.setTitle("View Create");
		this.setSize(400,300);
		this.setLocation(800,0);
		this.setLayout(new GridLayout(4,1));
		JTextField t1 = new JTextField("Type a new user name here.");
		JTextField t2 = new JTextField("Type a number of books here.");
		cb =new JComboBox<String>();//create a combo box 
		cb.addItem("Lender");//type 0
		cb.addItem("Borrower");//type 1
		this.add(t1);
		this.add(t2);
		this.add(cb);
		JButton b3 = new JButton("Create");
		b3.addActionListener(new ActionListener() {//add listener to button
			public void actionPerformed(ActionEvent e) {
				String name = t1.getText();
				String result = t2.getText();
				String action = c.create(name, result, cb.getSelectedIndex());//show the details
				if(action.equals("") == false) {
					JOptionPane.showMessageDialog(null, action,"Message", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		this.add(b3);
		setVisible(true);
	}
	
	public void update() {
		
	}
}
