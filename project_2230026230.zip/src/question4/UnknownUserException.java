package question4;

public class UnknownUserException extends Exception{
	
	public UnknownUserException(String msg) {
		super(msg);
	}
	
}