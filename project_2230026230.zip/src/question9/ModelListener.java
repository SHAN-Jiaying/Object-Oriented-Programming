package question9;

public interface ModelListener {
	public void update();
}