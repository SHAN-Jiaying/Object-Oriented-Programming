package question9;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class GUI {
    public static void main(String[] args) {
    	javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				Library lib = new Library("UIC Library");
				try {
					lib.addUser(new Borrower("Bob", 10));
					lib.addUser(new Lender("Linda", 5));
				} catch (NotALenderException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				ControllerSimple cs = new ControllerSimple(lib);
				ViewSimple vs = new ViewSimple(lib, cs);
				
				ControllerGetBook cgb = new ControllerGetBook(lib);
				ViewGetBook vgb = new ViewGetBook(lib, cgb);
            }
        });
    }
}