package question11;

public class ControllerGetBook extends Controller{
	public ControllerGetBook(Library m) {
		super(m);
	}
	
	public String getBook(String name) {
		
		try {
			int num = m.getBook(name);
			return "User " + name + " is borrowing " + num + " books.";
		}
		
		catch(UnknownUserException e){
			return e.getMessage();
		}
		
	}
}
