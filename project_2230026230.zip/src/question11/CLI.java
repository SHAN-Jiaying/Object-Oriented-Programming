package question11;

import java.util.Scanner;
import java.util.InputMismatchException;

public class CLI {
	private static Scanner input = new Scanner(System.in);

	private static String readLine(String message) {
		System.out.print(message);//print the message
		return input.nextLine();
	}

	private static int readPosInt(String message) {
        while (true) {
            System.out.print(message);//print the message
            try {
                int num = input.nextInt();//read the next line from user
                input.nextLine();
                
                if (num >= 0) {
                    return num;
                } 
                
                else {//num<0
                    System.out.println("Positive integers only!");
                }
                
            } catch (InputMismatchException e) {//not a integer
                System.out.println("You must type an integer!");
                input.nextLine();
            }
        }
    }

	public static void main(String[] args) {//do six different actions
		Library lib = new Library("UIC Library");
		
		while(true){//repeat the menu and ask the user to type an integer again
			int action = readPosInt("Type an action (total:1 add:2 get:3 more:4 less:5 quit:6): ");
			
			switch(action){
			
				case 1://Total number of borrowed books
					System.out.println("Total number of borrowed books: "+ lib.totalBorrowedBooks());
					break;
				
				case 2://Type the user role
					int get = readPosInt("Type the user role (lender:1 borrower:2): ");
					
					try {
						if(get == 1){//choose lender 
							 String name = readLine("Enter the name of the user: "); //name of the user
							 int iniBook =  readPosInt("Enter the initial number of borrowed books: "); //number of borrowed books
							 Lender lend = new Lender(name, iniBook);
							 lib.addUser(lend);
							 System.out.println("Lender \"" + name + "\" lending " + iniBook + " book(s) has been added.");//print the message
						}
						
						else if(get == 2){//choose borrower
							String name = readLine("Enter the name of the user: "); //name of the user
							int iniBook =  readPosInt("Enter the initial number of borrowed books: "); //number of borrowed books
							Borrower borrow = new Borrower(name, iniBook);
							lib.addUser(borrow);
							System.out.println("Borrower \"" + name + "\" borrowing " + iniBook + " book(s) has been added.");//print the message
						}
						
						else{//Unknown user
							System.out.println("Unknown user role!");
						}
					}
					
					catch(NotALenderException e) {//error
						System.out.println("BUG! This must never happen!");//print the message
						System.exit(1);
					}
					break;
					
				case 3://get the number of books borrowed by user
					String name3 = readLine("Enter the name of the user: ");//find user's name
					
					try{
						System.out.println(name3 + " borrows " + lib.getBook(name3) + " book(s)");//print the message
					}
					
					catch(UnknownUserException e){//unknown
						System.out.println("User " + name3 + " unknown");
					}
					
					break;
					
				case 4://increasing the number of books of a user
					String name4 = readLine("Enter the name of the user: ");//the name of the user
					int iniBook4 = readPosInt("Enter the number of books: ");//the number of books
					
					try{
						lib.moreBook(name4, iniBook4);
					}
					
					catch(UnknownUserException e){//unknown
						System.out.println("User " + name4 + " unknown.");
					} 
					
					catch (NotALenderException e){//error
						System.out.println("BUG! This must never happen!");
						System.exit(1);
					}
					
					break;
					
				case 5:// decreasing the number of books of a user
					String name5 = readLine("Enter the name of the user: ");//the name of the user
					int iniBook5 = readPosInt("Enter the number of books: ");//the number of books
					
					try{
						lib.moreBook(name5, -iniBook5);
					}
					
					catch(UnknownUserException e){//unknown
						System.out.println("User " + name5 + " unknown.");
					} 
					
					catch (NotALenderException e){//error
						System.out.println(e.getMessage());
					}
					
					break;
					
				case 6://exit the program
					System.out.println("Goodbye!");
                    System.exit(0);
							
				default://other condition
					System.out.println("Unknown action!");
			}
		}
	}
}
