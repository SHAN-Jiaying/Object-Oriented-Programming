package question11;

public class ControllerMoreBook extends Controller{
	public ControllerMoreBook(Library m) {
		super(m);
	}
	
	public String moreBook(String name,String number) {
		
		try {
			int num = Integer.parseInt(number);//String number to int
			m.moreBook(name, num);
			return "";
		}
		catch(UnknownUserException e) {//catch UnknownUserException
			return e.getMessage();
		}
		catch(NotALenderException e) {//catch NotALenderException
			return e.getMessage();
		}
		catch(NumberFormatException e) {//catch numberFormatException
			return e.getMessage();
		}
	}
}