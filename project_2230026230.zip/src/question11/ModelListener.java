package question11;

public interface ModelListener {
	public void update();
}