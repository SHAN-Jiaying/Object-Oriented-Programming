package question1;

public class Test {
	public static void main(String[] args) {
		User.testUser();
	}
}